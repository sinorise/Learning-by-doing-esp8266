/*
 * ESPRSSIF MIT License
 *
 * Copyright (c) 2015 <ESPRESSIF SYSTEMS (SHANGHAI) PTE LTD>
 *
 * Permission is hereby granted for use on ESPRESSIF SYSTEMS ESP8266 only, in which case,
 * it is free of charge, to any person obtaining a copy of this software and associated
 * documentation files (the "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the Software is furnished
 * to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all copies or
 * substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
 * FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#include "esp_common.h"
#include "gpio.h"
#include "ds18b20.h"


#define PIDENABLE 1
#if(PIDENABLE==1)
#include "pid.h"
	int WindowSize = 1000;
	unsigned long windowStartTime;
#endif
/******************************************************************************
 * FunctionName : user_rf_cal_sector_set
 * Description  : SDK just reversed 4 sectors, used for rf init data and paramters.
 *                We add this function to force users to set rf cal sector, since
 *                we don't know which sector is free in user's application.
 *                sector map for last several sectors : ABCCC
 *                A : rf cal
 *                B : rf init data
 *                C : sdk parameters
 * Parameters   : none
 * Returns      : rf cal sector
*******************************************************************************/
uint32 user_rf_cal_sector_set(void)
{
    flash_size_map size_map = system_get_flash_size_map();
    uint32 rf_cal_sec = 0;

    switch (size_map) {
        case FLASH_SIZE_4M_MAP_256_256:
            rf_cal_sec = 128 - 5;
            break;

        case FLASH_SIZE_8M_MAP_512_512:
            rf_cal_sec = 256 - 5;
            break;

        case FLASH_SIZE_16M_MAP_512_512:
        case FLASH_SIZE_16M_MAP_1024_1024:
            rf_cal_sec = 512 - 5;
            break;

        case FLASH_SIZE_32M_MAP_512_512:
        case FLASH_SIZE_32M_MAP_1024_1024:
            rf_cal_sec = 1024 - 5;
            break;
        case FLASH_SIZE_64M_MAP_1024_1024:
            rf_cal_sec = 2048 - 5;
            break;
        case FLASH_SIZE_128M_MAP_1024_1024:
            rf_cal_sec = 4096 - 5;
            break;
        default:
            rf_cal_sec = 0;
            break;
    }

    return rf_cal_sec;
}


struct reading;


void ICACHE_FLASH_ATTR
user_task(void *pvParameters)
{
	printf("----------Begin to user task-----\r\n");
	//static
	setup_DS1820();


#if(PIDENABLE==1)

	windowStartTime = millis();

	Pid myPID;

	//Define Variables we'll be connecting to
	float Setpoint, Input, Output;

	//Specify the links and initial tuning parameters
	float Kp=2, Ki=5, Kd=1;

	//PID myPID(&Input, &Output, &Setpoint, Kp, Ki, Kd, DIRECT);
	pid_init(&myPID, &Input, &Output, &Setpoint, Kp, Ki, Kd, PID_DIRECT);


	//initialize the variables we're linked to
	Input = (float)reading.temperature*1.0;//system_adc_read()*1024.0;	//analogRead(PIN_INPUT);

	  //this is the point(temperature) we want to reach
	Setpoint = 20;

	  //tell the PID to range between 0 and 255 //myPID.SetOutputLimits(0, 255);
	pid_setOutputLimits(&myPID, 0, WindowSize);

	  //turn the PID on
	pid_setMode( &myPID, PID_AUTOMATIC);

#endif
	while(1)
	{
		readDS18B20();
		if(reading.success)
		{
		    printf("Got a DS18B20 Reading: %d.%d\r\n" ,
		    (int)reading.temperature,
		    (int)(reading.temperature - (int)reading.temperature) * 100);

#if(PIDENABLE==1)
		Input = (float)reading.temperature*1.0;//system_adc_read()*1024.0;

		pid_compute(&myPID);

		/************************************************
		   * turn the output pin on/off based on pid output
		   ************************************************/
		if (millis() - windowStartTime > WindowSize)
		{ //time to shift the Relay Window
		    windowStartTime += WindowSize;
		}
		if (Output < millis() - windowStartTime)     gpio16_output_conf(),gpio16_output_set(1);//GPIO_OUTPUT_SET(RELAY_IO_NUM, 1);//digitalWrite(RELAY_PIN, HIGH);
		  else		gpio16_output_conf(),gpio16_output_set(0);//GPIO_OUTPUT_SET(RELAY_IO_NUM, 0);//digitalWrite(RELAY_PIN, LOW);

		//analogWrite(PIN_OUTPUT, Output);
		printf("Output %d.%d\r\n",((int)(*(myPID.myOutput)*10))/10,((int)(*(myPID.myOutput)*10))%10);

#endif

		}

		vTaskDelay(1000 / portTICK_RATE_MS);
	}
}
/******************************************************************************
 * FunctionName : user_init
 * Description  : entry of user application, init user function here
 * Parameters   : none
 * Returns      : none
*******************************************************************************/
void user_init(void)
{

	char buf[64] = { 0 };
    u8 ret;

    uart_init_new();//115200bps

  //  system_update_cpu_freq(SYS_CPU_160MHZ);

    sprintf(buf, "compile time:%s %s", __DATE__, __TIME__);
    printf("uart init ok, %s\n", buf);
    printf("SDK version: %s \n", system_get_sdk_version());
    printf("ESP8266	chip	ID:0x%x\n",	system_get_chip_id());
    printf("SDK version:%s\n", system_get_sdk_version());
    printf("heap size:%d\n", system_get_free_heap_size());
    printf("cpu freq:%d\n", system_get_cpu_freq());

    xTaskCreate(user_task, "user_task", 512, NULL, 8, NULL);
}


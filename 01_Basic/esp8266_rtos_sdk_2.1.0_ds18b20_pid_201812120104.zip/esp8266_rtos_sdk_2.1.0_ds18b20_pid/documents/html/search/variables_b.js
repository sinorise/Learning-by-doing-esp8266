var searchData=
[
  ['old_5fmode',['old_mode',['../structEvent__StaMode__AuthMode__Change__t.html#aec107fd7e68f2881586ebd4c9d1df031',1,'Event_StaMode_AuthMode_Change_t']]]
];
